from tkinter import * 

root = Tk()
root.title("Form")
root.geometry("500x300")

fields = "First Name", "Last Name", "Course Name", "Country"

def build_form(root, fields):
    for field in fields:
        frame = Frame(root)
        label = Label(frame, text = field, pady = 20, font = ("Helvetica", 20))
        entry = Entry(frame)
        label.pack(side = LEFT)
        frame.pack(side = TOP)
        entry.pack(side = RIGHT)

entries = build_form(root, fields)

root.mainloop()